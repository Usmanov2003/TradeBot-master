---
name: Request
about: Suggest any new features or changes you would like to see
title: ''
labels: proposal
assignees: ''

---

Describe what you would like to be changed, added, or improved.
