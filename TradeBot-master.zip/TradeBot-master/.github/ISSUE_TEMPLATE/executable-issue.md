---
name: Executable issue
about: Issue encountered while using the compiled executable
title: ''
labels: release
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Select mode '...'
2. Do '....'
3. See error

**Logs**
```
<PASTE LOGS HERE>
```

**Desktop:**
 - OS: Windows 10

**Additional context**
Add any other context about the problem here.
