---
name: Source code bug report
about: Issue with the codebase
title: ''
labels: framework
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Line numbers**
Link to relevant lines with the GitHub permalink feature

**Proposed fix**
If you know what needs to be changed add it here and maybe even submit a PR
